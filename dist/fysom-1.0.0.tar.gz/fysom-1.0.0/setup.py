from setuptools import setup

setup(
    name='fysom',
    version='1.0.0',
    packages=['.'],
)
